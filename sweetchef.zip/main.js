console.log('Hello World!');
function openNav() {
  document.getElementById("nav").style.width = "250px";
}
function closeNav() {
  document.getElementById("nav").style.width = "0";
}
